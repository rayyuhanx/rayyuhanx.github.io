﻿using System;
using System.Windows.Forms;
using System.ServiceProcess;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Management;
using System.Drawing;

namespace ServiceMemoryDetector
{
    public partial class MainForm : Form
    {
        #region Private

        MainForm _form;
        ServiceItem _service;
        Process _process;
        PerformanceCounter _counter;
        ServiceController _controller;

        void _reloadData(string search = "")
        {
            List<ServiceItem> _dataSource = new List<ServiceItem>();
            // Get all services
            var services = ServiceController.GetServices()
                                            .Where(s => s.ServiceType == ServiceType.Win32OwnProcess && s.DisplayName.IndexOf(search) > -1)
                                            .OrderBy(s => s.ServiceName).ToArray();
            // Push to `_dataSource`
            for (int i = 0; i < services.Length; i++)
                _dataSource.Add(new ServiceItem
                {
                    No = i + 1,
                    DisplayName = services[i].DisplayName,
                    ServiceName = services[i].ServiceName,
                    Status = services[i].Status
                });
            // Bind datasource
            dataGridView_services.DataSource = _dataSource;
        }

        void _detectService()
        {
            var processId = 0u;
            var mos = new ManagementObjectSearcher($"SELECT ProcessId FROM Win32_Service WHERE Name='{_service.ServiceName}'");
            foreach (ManagementObject item in mos.Get())
                processId = (uint)item["ProcessId"];

            _process = Process.GetProcessById((int)processId);
            _counter = new PerformanceCounter("Process", "Working Set", _process.ProcessName);
        }

        void _displayInfo(string info, bool isRed = true)
        {
            label_info.Text = info;
            label_info.ForeColor = isRed ? Color.Red : Color.Green;
        }

        #endregion

        public MainForm()
        {
            InitializeComponent();

            // Set datagridView
            dataGridView_services.AutoGenerateColumns = false;
            // Bind Event
            this.Load += UnifiedEntry;
            timer_auto_refresh.Tick += UnifiedEntry;

            _form = this;
        }

        private void UnifiedEntry(object sender, EventArgs e)
        {
            _reloadData(textBox_search.Text);
        }

        private void textBox_search_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Enter key
            if (e.KeyChar == '\r')
            {
                e.Handled = true;
                UnifiedEntry(sender, e);
            }
            if (e.KeyChar == '\b' || e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122) { } // Valid chars
            else e.Handled = true;
        }

        private void button_auto_refresh_Click(object sender, EventArgs e)
        {
            if (timer_auto_refresh.Enabled)
            {
                timer_auto_refresh.Enabled = false;
                button_auto_refresh.Text = "execute";
                numericUpDown_seconds.Enabled = true;
            }
            else
            {
                timer_auto_refresh.Interval = (int)numericUpDown_seconds.Value * 1000;

                timer_auto_refresh.Enabled = true;
                button_auto_refresh.Text = "stop it";
                numericUpDown_seconds.Enabled = false;
            }
        }

        private void button_detect_Click(object sender, EventArgs e)
        {
            // Check if stop detect
            if (button_detect.Text == "stop")
            {
                button_detect.Text = "watch it";
                textBox_memory.Enabled = true;
                timer_detect.Stop();

                // Recyle
                _controller = null;
                _process = null;
                _counter = null;

                return;
            }

            // Check `memory` text
            var memory = textBox_memory.Text;
            int.TryParse(memory, out int memoryInt);

            if (memoryInt == 0)
            {
                textBox_memory.Focus();
                return;
            }
            // Comfirm selected
            if (MessageBox.Show("Please comfirm selected service", "Tips", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                // Get `selected service`
                _service = (ServiceItem)dataGridView_services.CurrentRow.DataBoundItem;
                // Check `selected service` is running
                if (_service.Status != ServiceControllerStatus.Running)
                {
                    _displayInfo($"It is stopped");
                    return;
                }

                // Detect service
                _controller = new ServiceController(_service.ServiceName);
                _detectService();

                // Switch `Enable`
                timer_detect.Start();
                textBox_memory.Enabled = false;

                button_detect.Text = "stop";

                _displayInfo("Watching...", false);
            }
        }

        private void timer_detect_Tick(object sender, EventArgs e)
        {
            var usage = _counter.NextValue() / 1024;

            // Display
            _form.Text = $"Detecting: [{_service.DisplayName}] - [{usage}/kb]";

            // Check if usage exceed limit number
            if (usage > int.Parse(textBox_memory.Text))
            {
                button_detect_Click(sender, e);
                // Send notification
                MessageBox.Show($"{_service.DisplayName} is rampage!!!", "Tips", MessageBoxButtons.OK);
                //_controller.Stop();
                //_controller.WaitForStatus(ServiceControllerStatus.Stopped);
                //_controller.Start();
            }
        }

        private void button_start_service_Click(object sender, EventArgs e)
        {
            if (_controller == null)
            {
                _displayInfo("No service is watching");
                return;
            }

            _controller = new ServiceController(_service.ServiceName);
            _controller.Start();

            _displayInfo($"Start success", true);
        }

        private void button_stop_service_Click(object sender, EventArgs e)
        {
            if (_controller == null)
            {
                _displayInfo("No service is watching");
                return;
            }

            _controller.Stop();
            _displayInfo($"Stop success", true);
        }
    }

    public class ServiceItem
    {
        public int No { get; set; }
        public string DisplayName { get; set; }
        public string ServiceName { get; set; }
        public ServiceControllerStatus Status { get; set; }
    }
}
