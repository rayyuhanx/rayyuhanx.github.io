﻿namespace ServiceMemoryDetector
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel_services = new System.Windows.Forms.Panel();
            this.dataGridView_services = new System.Windows.Forms.DataGridView();
            this.No = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DisplayName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ServiceName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel_buttons = new System.Windows.Forms.Panel();
            this.groupBox_detect = new System.Windows.Forms.GroupBox();
            this.button_detect = new System.Windows.Forms.Button();
            this.groupBox_auto_refresh = new System.Windows.Forms.GroupBox();
            this.label_seconds = new System.Windows.Forms.Label();
            this.numericUpDown_seconds = new System.Windows.Forms.NumericUpDown();
            this.button_auto_refresh = new System.Windows.Forms.Button();
            this.groupBox_quick_search = new System.Windows.Forms.GroupBox();
            this.textBox_search = new System.Windows.Forms.TextBox();
            this.timer_auto_refresh = new System.Windows.Forms.Timer(this.components);
            this.textBox_memory = new System.Windows.Forms.TextBox();
            this.label_kb = new System.Windows.Forms.Label();
            this.timer_detect = new System.Windows.Forms.Timer(this.components);
            this.button_start_service = new System.Windows.Forms.Button();
            this.button_stop_service = new System.Windows.Forms.Button();
            this.label_info = new System.Windows.Forms.Label();
            this.panel_services.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_services)).BeginInit();
            this.panel_buttons.SuspendLayout();
            this.groupBox_detect.SuspendLayout();
            this.groupBox_auto_refresh.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_seconds)).BeginInit();
            this.groupBox_quick_search.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_services
            // 
            this.panel_services.Controls.Add(this.dataGridView_services);
            this.panel_services.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_services.Location = new System.Drawing.Point(0, 0);
            this.panel_services.Name = "panel_services";
            this.panel_services.Size = new System.Drawing.Size(468, 362);
            this.panel_services.TabIndex = 0;
            // 
            // dataGridView_services
            // 
            this.dataGridView_services.AllowUserToAddRows = false;
            this.dataGridView_services.AllowUserToDeleteRows = false;
            this.dataGridView_services.AllowUserToResizeRows = false;
            this.dataGridView_services.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView_services.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView_services.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_services.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.No,
            this.DisplayName,
            this.ServiceName,
            this.Status});
            this.dataGridView_services.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_services.Location = new System.Drawing.Point(0, 0);
            this.dataGridView_services.MultiSelect = false;
            this.dataGridView_services.Name = "dataGridView_services";
            this.dataGridView_services.ReadOnly = true;
            this.dataGridView_services.RowHeadersVisible = false;
            this.dataGridView_services.RowTemplate.Height = 23;
            this.dataGridView_services.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_services.Size = new System.Drawing.Size(468, 362);
            this.dataGridView_services.TabIndex = 0;
            // 
            // No
            // 
            this.No.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.No.DataPropertyName = "No";
            this.No.HeaderText = "No";
            this.No.Name = "No";
            this.No.ReadOnly = true;
            this.No.Width = 40;
            // 
            // DisplayName
            // 
            this.DisplayName.DataPropertyName = "DisplayName";
            this.DisplayName.HeaderText = "Display Name";
            this.DisplayName.Name = "DisplayName";
            this.DisplayName.ReadOnly = true;
            this.DisplayName.Width = 170;
            // 
            // ServiceName
            // 
            this.ServiceName.DataPropertyName = "ServiceName";
            this.ServiceName.HeaderText = "Service Name";
            this.ServiceName.Name = "ServiceName";
            this.ServiceName.ReadOnly = true;
            this.ServiceName.Width = 170;
            // 
            // Status
            // 
            this.Status.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Status.DataPropertyName = "Status";
            this.Status.HeaderText = "Status";
            this.Status.Name = "Status";
            this.Status.ReadOnly = true;
            this.Status.Width = 70;
            // 
            // panel_buttons
            // 
            this.panel_buttons.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_buttons.Controls.Add(this.label_info);
            this.panel_buttons.Controls.Add(this.groupBox_detect);
            this.panel_buttons.Controls.Add(this.groupBox_auto_refresh);
            this.panel_buttons.Controls.Add(this.groupBox_quick_search);
            this.panel_buttons.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel_buttons.Location = new System.Drawing.Point(470, 0);
            this.panel_buttons.Name = "panel_buttons";
            this.panel_buttons.Size = new System.Drawing.Size(114, 362);
            this.panel_buttons.TabIndex = 1;
            // 
            // groupBox_detect
            // 
            this.groupBox_detect.Controls.Add(this.button_stop_service);
            this.groupBox_detect.Controls.Add(this.button_start_service);
            this.groupBox_detect.Controls.Add(this.label_kb);
            this.groupBox_detect.Controls.Add(this.textBox_memory);
            this.groupBox_detect.Controls.Add(this.button_detect);
            this.groupBox_detect.Location = new System.Drawing.Point(3, 165);
            this.groupBox_detect.Name = "groupBox_detect";
            this.groupBox_detect.Size = new System.Drawing.Size(106, 138);
            this.groupBox_detect.TabIndex = 4;
            this.groupBox_detect.TabStop = false;
            this.groupBox_detect.Text = "Detect service";
            // 
            // button_detect
            // 
            this.button_detect.Location = new System.Drawing.Point(15, 48);
            this.button_detect.Name = "button_detect";
            this.button_detect.Size = new System.Drawing.Size(75, 23);
            this.button_detect.TabIndex = 1;
            this.button_detect.Text = "watch it";
            this.button_detect.UseVisualStyleBackColor = true;
            this.button_detect.Click += new System.EventHandler(this.button_detect_Click);
            // 
            // groupBox_auto_refresh
            // 
            this.groupBox_auto_refresh.Controls.Add(this.label_seconds);
            this.groupBox_auto_refresh.Controls.Add(this.numericUpDown_seconds);
            this.groupBox_auto_refresh.Controls.Add(this.button_auto_refresh);
            this.groupBox_auto_refresh.Location = new System.Drawing.Point(3, 81);
            this.groupBox_auto_refresh.Name = "groupBox_auto_refresh";
            this.groupBox_auto_refresh.Size = new System.Drawing.Size(106, 78);
            this.groupBox_auto_refresh.TabIndex = 3;
            this.groupBox_auto_refresh.TabStop = false;
            this.groupBox_auto_refresh.Text = "Auto refresh";
            // 
            // label_seconds
            // 
            this.label_seconds.AutoSize = true;
            this.label_seconds.Location = new System.Drawing.Point(6, 24);
            this.label_seconds.Name = "label_seconds";
            this.label_seconds.Size = new System.Drawing.Size(53, 12);
            this.label_seconds.TabIndex = 3;
            this.label_seconds.Text = "seconds:";
            // 
            // numericUpDown_seconds
            // 
            this.numericUpDown_seconds.Location = new System.Drawing.Point(60, 21);
            this.numericUpDown_seconds.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.numericUpDown_seconds.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numericUpDown_seconds.Name = "numericUpDown_seconds";
            this.numericUpDown_seconds.Size = new System.Drawing.Size(40, 21);
            this.numericUpDown_seconds.TabIndex = 2;
            this.numericUpDown_seconds.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // button_auto_refresh
            // 
            this.button_auto_refresh.Location = new System.Drawing.Point(15, 48);
            this.button_auto_refresh.Name = "button_auto_refresh";
            this.button_auto_refresh.Size = new System.Drawing.Size(75, 23);
            this.button_auto_refresh.TabIndex = 1;
            this.button_auto_refresh.Text = "execute";
            this.button_auto_refresh.UseVisualStyleBackColor = true;
            this.button_auto_refresh.Click += new System.EventHandler(this.button_auto_refresh_Click);
            // 
            // groupBox_quick_search
            // 
            this.groupBox_quick_search.Controls.Add(this.textBox_search);
            this.groupBox_quick_search.Location = new System.Drawing.Point(3, 1);
            this.groupBox_quick_search.Name = "groupBox_quick_search";
            this.groupBox_quick_search.Size = new System.Drawing.Size(106, 71);
            this.groupBox_quick_search.TabIndex = 2;
            this.groupBox_quick_search.TabStop = false;
            this.groupBox_quick_search.Text = "Quick search";
            // 
            // textBox_search
            // 
            this.textBox_search.Location = new System.Drawing.Point(6, 20);
            this.textBox_search.Multiline = true;
            this.textBox_search.Name = "textBox_search";
            this.textBox_search.Size = new System.Drawing.Size(94, 43);
            this.textBox_search.TabIndex = 0;
            this.textBox_search.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_search_KeyPress);
            // 
            // textBox_memory
            // 
            this.textBox_memory.Location = new System.Drawing.Point(8, 21);
            this.textBox_memory.Name = "textBox_memory";
            this.textBox_memory.Size = new System.Drawing.Size(71, 21);
            this.textBox_memory.TabIndex = 3;
            this.textBox_memory.Text = "1024";
            // 
            // label_kb
            // 
            this.label_kb.AutoSize = true;
            this.label_kb.Location = new System.Drawing.Point(84, 25);
            this.label_kb.Name = "label_kb";
            this.label_kb.Size = new System.Drawing.Size(17, 12);
            this.label_kb.TabIndex = 1;
            this.label_kb.Text = "kb";
            // 
            // timer_detect
            // 
            this.timer_detect.Interval = 1000;
            this.timer_detect.Tick += new System.EventHandler(this.timer_detect_Tick);
            // 
            // button_start_service
            // 
            this.button_start_service.Location = new System.Drawing.Point(15, 77);
            this.button_start_service.Name = "button_start_service";
            this.button_start_service.Size = new System.Drawing.Size(75, 23);
            this.button_start_service.TabIndex = 4;
            this.button_start_service.Text = "start it";
            this.button_start_service.UseVisualStyleBackColor = true;
            this.button_start_service.Click += new System.EventHandler(this.button_start_service_Click);
            // 
            // button_stop_service
            // 
            this.button_stop_service.Location = new System.Drawing.Point(15, 106);
            this.button_stop_service.Name = "button_stop_service";
            this.button_stop_service.Size = new System.Drawing.Size(75, 23);
            this.button_stop_service.TabIndex = 5;
            this.button_stop_service.Text = "stop it";
            this.button_stop_service.UseVisualStyleBackColor = true;
            this.button_stop_service.Click += new System.EventHandler(this.button_stop_service_Click);
            // 
            // label_info
            // 
            this.label_info.Location = new System.Drawing.Point(7, 318);
            this.label_info.Name = "label_info";
            this.label_info.Size = new System.Drawing.Size(100, 34);
            this.label_info.TabIndex = 5;
            this.label_info.Text = "infomation";
            this.label_info.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 362);
            this.Controls.Add(this.panel_buttons);
            this.Controls.Add(this.panel_services);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(600, 400);
            this.MinimumSize = new System.Drawing.Size(600, 400);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Service memory Detector";
            this.panel_services.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_services)).EndInit();
            this.panel_buttons.ResumeLayout(false);
            this.groupBox_detect.ResumeLayout(false);
            this.groupBox_detect.PerformLayout();
            this.groupBox_auto_refresh.ResumeLayout(false);
            this.groupBox_auto_refresh.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_seconds)).EndInit();
            this.groupBox_quick_search.ResumeLayout(false);
            this.groupBox_quick_search.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_services;
        private System.Windows.Forms.Panel panel_buttons;
        private System.Windows.Forms.DataGridView dataGridView_services;
        private System.Windows.Forms.GroupBox groupBox_quick_search;
        private System.Windows.Forms.TextBox textBox_search;
        private System.Windows.Forms.GroupBox groupBox_auto_refresh;
        private System.Windows.Forms.Button button_auto_refresh;
        private System.Windows.Forms.Label label_seconds;
        private System.Windows.Forms.NumericUpDown numericUpDown_seconds;
        private System.Windows.Forms.Timer timer_auto_refresh;
        private System.Windows.Forms.DataGridViewTextBoxColumn No;
        private System.Windows.Forms.DataGridViewTextBoxColumn DisplayName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ServiceName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
        private System.Windows.Forms.GroupBox groupBox_detect;
        private System.Windows.Forms.Button button_detect;
        private System.Windows.Forms.Label label_kb;
        private System.Windows.Forms.TextBox textBox_memory;
        private System.Windows.Forms.Timer timer_detect;
        private System.Windows.Forms.Button button_stop_service;
        private System.Windows.Forms.Button button_start_service;
        private System.Windows.Forms.Label label_info;
    }
}

